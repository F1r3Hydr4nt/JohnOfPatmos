/* Supply a definition of errno if one not already provided.  */

int errno;
